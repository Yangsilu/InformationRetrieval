//Silu Yang
//siluy@uci.edu
Course project if for UCI CS 221
Information Retrival

The templete is downloaded from CS221 course webpage of 2014.

And it meets the new requirements(such as print in a decreasing manner)

Palidrome comlexity:

    Checking a string is linear complexity. O(n)

    Checking the lists of tokens is polynomial time. O(n^3)// Check all n^2 poosible combination and for each string, Palirome check is O(n)

COdes:

I use Arraylists to store data.




